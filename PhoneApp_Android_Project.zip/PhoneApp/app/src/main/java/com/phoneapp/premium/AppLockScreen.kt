package com.phoneapp.premium

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * ऐप खोलते ही PIN माँगने वाली Lock Screen।
 * सही PIN डालते ही onUnlocked() कॉल होकर बाकी ऐप दिखने लगता है।
 */
@Composable
fun AppLockScreen(correctPin: String, onUnlocked: () -> Unit) {
    var entered by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    fun onDigit(d: String) {
        if (entered.length >= 4) return
        entered += d
        error = false
        if (entered.length == 4) {
            if (entered == correctPin) {
                onUnlocked()
            } else {
                error = true
                entered = ""
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xFF0B0F19)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
            Spacer(Modifier.height(12.dp))
            Text("ऐप खोलने के लिए PIN डालें", color = Color.White, fontSize = 15.sp)
            Spacer(Modifier.height(18.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                repeat(4) { i ->
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .background(
                                if (i < entered.length) (if (error) Color(0xFFE5484D) else Color.White) else Color(0xFF334155),
                                CircleShape
                            )
                    )
                }
            }
            if (error) {
                Spacer(Modifier.height(10.dp))
                Text("गलत PIN, फिर कोशिश करें", color = Color(0xFFE5484D), fontSize = 12.sp)
            }

            Spacer(Modifier.height(28.dp))
            val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫")
            for (row in keys.chunked(3)) {
                Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                    for (key in row) {
                        Box(
                            modifier = Modifier.size(64.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            when {
                                key == "" -> {}
                                key == "⌫" -> IconButton(onClick = { entered = entered.dropLast(1); error = false }) {
                                    Icon(Icons.Filled.Backspace, contentDescription = "Backspace", tint = Color.White)
                                }
                                else -> TextButton(onClick = { onDigit(key) }) {
                                    Text(key, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}

/**
 * Settings से "App Lock" चालू करते वक़्त नया 4-अंकों का PIN सेट करने वाला Dialog।
 */
@Composable
fun SetPinDialog(onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("नया PIN सेट करें") },
        text = {
            Column {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pin = it },
                    label = { Text("4-अंकों का PIN") },
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = confirmPin,
                    onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) confirmPin = it },
                    label = { Text("PIN दोबारा डालें") },
                    singleLine = true
                )
                error?.let {
                    Spacer(Modifier.height(6.dp))
                    Text(it, color = Color(0xFFE5484D), fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    pin.length != 4 -> error = "4 अंकों का PIN डालें"
                    pin != confirmPin -> error = "दोनों PIN एक जैसे नहीं हैं"
                    else -> onConfirm(pin)
                }
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
