package com.phoneapp.premium

import android.content.Context

object AppLockStore {
    private const val PREFS = "app_lock"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("enabled", false)

    fun getPin(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("pin", "") ?: ""

    fun setLock(context: Context, enabled: Boolean, pin: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("enabled", enabled)
            .putString("pin", pin)
            .apply()
    }
}
